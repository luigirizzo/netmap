/* Broadcom NetXtreme-C/E network driver.
 *
 * Copyright (c) 2016-2018 Broadcom Limited
 * Copyright (c) 2018-2021 Broadcom Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 */

#ifndef BNXT_EXTRA_VER_H
#define BNXT_EXTRA_VER_H

#ifndef DRV_MODULE_EXTRA_VER
#define DRV_MODULE_EXTRA_VER  "-226.0.85.0"
#endif

#endif
