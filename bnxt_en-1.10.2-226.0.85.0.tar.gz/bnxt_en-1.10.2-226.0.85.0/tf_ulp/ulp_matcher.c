// SPDX-License-Identifier: BSD-3-Clause
/* Copyright(c) 2019-2021 Broadcom
 * All rights reserved.
 */

#include "bnxt_compat.h"
#include "ulp_matcher.h"
#include "ulp_utils.h"
#include "ulp_template_debug_proto.h"

#ifdef CONFIG_BNXT_FLOWER_OFFLOAD
/* Utility function to calculate the class matcher hash */
static u32
ulp_matcher_class_hash_calculate(u64 hi_sig, u64 lo_sig)
{
	u64 hash;

	hi_sig |= ((hi_sig % BNXT_ULP_CLASS_HID_HIGH_PRIME) <<
		   BNXT_ULP_CLASS_HID_SHFTL);
	lo_sig |= ((lo_sig % BNXT_ULP_CLASS_HID_LOW_PRIME) <<
		   (BNXT_ULP_CLASS_HID_SHFTL + 2));
	hash = hi_sig ^ lo_sig;
	hash = (hash >> BNXT_ULP_CLASS_HID_SHFTR) & BNXT_ULP_CLASS_HID_MASK;
	return (u32)hash;
}

/* Utility function to calculate the action matcher hash */
static u32
ulp_matcher_action_hash_calculate(u64 hi_sig, u64 app_id)
{
	u64 hash;

	hi_sig |= ((hi_sig % BNXT_ULP_ACT_HID_HIGH_PRIME) <<
		   BNXT_ULP_ACT_HID_SHFTL);
	app_id |= ((app_id % BNXT_ULP_ACT_HID_LOW_PRIME) <<
		   (BNXT_ULP_ACT_HID_SHFTL + 2));
	hash = hi_sig ^ app_id;
	hash = (hash >> BNXT_ULP_ACT_HID_SHFTR) & BNXT_ULP_ACT_HID_MASK;
	return (u32)hash;
}

/* Function to handle the matching of RTE Flows and validating
 * the pattern masks against the flow templates.
 */
int
ulp_matcher_pattern_match(struct ulp_tc_parser_params *params,
			  u32 *class_id)
{
	struct bnxt_ulp_class_match_info *class_match;
	u32 class_hid;
	u16 tmpl_id;

	/* calculate the hash of the given flow */
	class_hid = ulp_matcher_class_hash_calculate((params->hdr_bitmap.bits ^
						     params->app_id),
						     params->fld_s_bitmap.bits);

	/* validate the calculate hash values */
	if (class_hid >= BNXT_ULP_CLASS_SIG_TBL_MAX_SZ)
		goto error;
	tmpl_id = ulp_class_sig_tbl[class_hid];
	if (!tmpl_id)
		goto error;

	class_match = &ulp_class_match_list[tmpl_id];
	if (ULP_BITMAP_CMP(&params->hdr_bitmap, &class_match->hdr_sig)) {
		netdev_dbg(params->ulp_ctx->bp->dev, "Proto Header does not match\n");
		goto error;
	}
	if (ULP_BITMAP_CMP(&params->fld_s_bitmap, &class_match->field_sig)) {
		netdev_dbg(params->ulp_ctx->bp->dev, "Field signature does not match\n");
		goto error;
	}

	/* Match the application id before proceeding */
	if (params->app_id != class_match->app_sig) {
		netdev_dbg(params->ulp_ctx->bp->dev, "Field to match the app id %u:%u\n",
			   params->app_id, class_match->app_sig);
		goto error;
	}

	netdev_dbg(params->ulp_ctx->bp->dev, "Found matching pattern template %d\n",
		   class_match->class_tid);
	*class_id = class_match->class_tid;
	params->hdr_sig_id = class_match->hdr_sig_id;
	params->flow_sig_id = class_match->flow_sig_id;
	params->flow_pattern_id = class_match->flow_pattern_id;
	return BNXT_TF_RC_SUCCESS;

error:
	netdev_err(params->ulp_ctx->bp->dev, "Did not find any matching template\n");
	netdev_err(params->ulp_ctx->bp->dev,
		   "class_hid:0x%x, Hdr:0x%llx Fld:0x%llx SFld:0x%llx\n",
		   class_hid, params->hdr_bitmap.bits,
		   params->fld_bitmap.bits, params->fld_s_bitmap.bits);
	*class_id = 0;
	return BNXT_TF_RC_ERROR;
}

/* Function to handle the matching of RTE Flows and validating
 * the action against the flow templates.
 */
int
ulp_matcher_action_match(struct ulp_tc_parser_params *params,
			 u32 *act_id)
{
	struct bnxt_ulp_act_match_info *act_match;
	u32 act_hid;
	u16 tmpl_id;

	/* calculate the hash of the given flow action */
	act_hid = ulp_matcher_action_hash_calculate(params->act_bitmap.bits,
						    params->app_id);

	/* validate the calculate hash values */
	if (act_hid >= BNXT_ULP_ACT_SIG_TBL_MAX_SZ)
		goto error;
	tmpl_id = ulp_act_sig_tbl[act_hid];
	if (!tmpl_id)
		goto error;

	act_match = &ulp_act_match_list[tmpl_id];
	if (ULP_BITMAP_CMP(&params->act_bitmap, &act_match->act_sig)) {
		netdev_dbg(params->ulp_ctx->bp->dev, "Action Header does not match\n");
		goto error;
	}

	/* Match the application id before proceeding */
	if (params->app_id != act_match->app_sig) {
		netdev_dbg(params->ulp_ctx->bp->dev, "Field to match the app id %u:%u\n",
			   params->app_id, act_match->app_sig);
		goto error;
	}

	*act_id = act_match->act_tid;
	params->act_pattern_id = act_match->act_pattern_id;
	netdev_dbg(params->ulp_ctx->bp->dev, "Found matching action template %u\n", *act_id);
	return BNXT_TF_RC_SUCCESS;

error:
	netdev_err(params->ulp_ctx->bp->dev, "Did not find any matching action template\n");
	netdev_err(params->ulp_ctx->bp->dev, "act_hid:0x%x, Hdr:%llx\n",
		   act_hid, params->act_bitmap.bits);
	*act_id = 0;
	return BNXT_TF_RC_ERROR;
}
#endif /* CONFIG_BNXT_FLOWER_OFFLOAD */
